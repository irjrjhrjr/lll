
					</div>
				</div>
				<footer class="footer">
					<div class="container">
						<div class="row">
							<div class="col-12 text-center">
								<?php echo $config['web']['title']; ?> &copy; Copyright <?php echo date("Y"); ?> Made with <i class="fa fa-heart text-danger"></i> by <a href="http://penuliskode.com" target="_blank">Penulis Kode</a>
							</div>
						</div>
					</div>
				</footer>
			</div>
		</div>
		
		<script src="<?php echo $config['web']['base_url'] ?>assets/js/jquery.core.js"></script>
		<script src="<?php echo $config['web']['base_url'] ?>assets/js/jquery.app.js"></script>

	</body>
</html>